
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","AboutController"],["c","BaseController"],["c","Devices"],["c","DevicesController"],["c","FrontController"],["c","IndexController"],["c","KodiController"],["c","KodiMovies"],["c","KodiMusic"],["c","KodiTVShowEpisodes"],["c","LoginForm"],["c","MenuItems"],["c","Menus"],["c","PHPSysInfo"],["c","RssController"],["c","SecurityPlugin"],["c","SessionController"],["c","SettingsController"],["c","SettingsDashboardForm"],["c","SettingsDeviceForm"],["c","SettingsGeneralForm"],["c","SettingsMenuItemForm"],["c","SettingsUsersForm"],["c","Users"]];
